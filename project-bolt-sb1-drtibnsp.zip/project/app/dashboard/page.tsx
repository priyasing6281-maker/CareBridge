'use client';

import { useEffect, useState, useCallback, useRef } from 'react';
import Link from 'next/link';
import { HeartPulse, Activity, Bell, Phone, Check, Settings as SettingsIcon, ArrowLeft, Save, Clock } from 'lucide-react';
import { getSupabase, classifyReading, DEFAULT_SETTINGS, type Reading, type Alert, type Settings, type Severity } from '@/lib/supabase/client';

export default function DashboardPage() {
  const [readings, setReadings] = useState<Reading[]>([]);
  const [alerts, setAlerts] = useState<Alert[]>([]);
  const [settings, setSettings] = useState<Settings>(DEFAULT_SETTINGS);
  const [settingsForm, setSettingsForm] = useState<Settings>(DEFAULT_SETTINGS);
  const [settingsSaved, setSettingsSaved] = useState(false);
  const [callStatus, setCallStatus] = useState<string | null>(null);
  const [calling, setCalling] = useState(false);
  const [latestReading, setLatestReading] = useState<Reading | null>(null);
  const settingsRef = useRef(settings);

  useEffect(() => {
    settingsRef.current = settings;
  }, [settings]);

  // Initial load + realtime subscriptions
  useEffect(() => {
    const supabase = getSupabase();

    // Load settings
    supabase
      .from('settings')
      .select('*')
      .eq('id', 1)
      .maybeSingle()
      .then(({ data }) => {
        if (data) {
          const s = data as Settings;
          setSettings(s);
          setSettingsForm(s);
        }
      });

    // Load recent readings
    supabase
      .from('readings')
      .select('*')
      .order('created_at', { ascending: false })
      .limit(20)
      .then(({ data }) => {
        if (data) {
          const r = data as Reading[];
          setReadings(r);
          if (r.length > 0) setLatestReading(r[0]);
        }
      });

    // Load recent alerts
    supabase
      .from('alerts')
      .select('*')
      .order('created_at', { ascending: false })
      .limit(50)
      .then(({ data }) => {
        if (data) setAlerts(data as Alert[]);
      });

    // Subscribe to readings
    const readingsChannel = supabase
      .channel('dash-readings')
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'readings' }, (payload) => {
        const newReading = payload.new as Reading;
        setLatestReading(newReading);
        setReadings((prev) => [newReading, ...prev].slice(0, 20));
      })
      .subscribe();

    // Subscribe to alerts
    const alertsChannel = supabase
      .channel('dash-alerts')
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'alerts' }, (payload) => {
        const newAlert = payload.new as Alert;
        setAlerts((prev) => [newAlert, ...prev].slice(0, 50));
      })
      .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'alerts' }, (payload) => {
        const updated = payload.new as Alert;
        setAlerts((prev) => prev.map((a) => (a.id === updated.id ? updated : a)));
      })
      .subscribe();

    // Subscribe to settings
    const settingsChannel = supabase
      .channel('dash-settings')
      .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'settings' }, (payload) => {
        const s = payload.new as Settings;
        setSettings(s);
        setSettingsForm(s);
      })
      .subscribe();

    return () => {
      supabase.removeChannel(readingsChannel);
      supabase.removeChannel(alertsChannel);
      supabase.removeChannel(settingsChannel);
    };
  }, []);

  const currentSeverity: Severity = latestReading
    ? classifyReading(latestReading.heart_rate, latestReading.temperature, settings)
    : 'normal';

  const acknowledgeAlert = useCallback(async (id: string) => {
    const supabase = getSupabase();
    await supabase.from('alerts').update({ acknowledged: true }).eq('id', id);
  }, []);

  const saveSettings = useCallback(async () => {
    const supabase = getSupabase();
    await supabase
      .from('settings')
      .upsert({
        id: 1,
        heart_rate_min: settingsForm.heart_rate_min,
        heart_rate_max: settingsForm.heart_rate_max,
        temperature_min: settingsForm.temperature_min,
        temperature_max: settingsForm.temperature_max,
      });
    setSettings(settingsForm);
    setSettingsSaved(true);
    setTimeout(() => setSettingsSaved(false), 3000);
  }, [settingsForm]);

  const callEmergencyContact = useCallback(async () => {
    setCalling(true);
    setCallStatus(null);
    try {
      const res = await fetch('/api/call', { method: 'POST' });
      const data = await res.json();
      if (!res.ok) {
        setCallStatus(`Failed: ${data.error || 'Unknown error'}`);
      } else {
        setCallStatus(data.message || 'Call placed successfully.');
      }
    } catch (err) {
      setCallStatus('Failed: Network error');
    } finally {
      setCalling(false);
      setTimeout(() => setCallStatus(null), 10000);
    }
  }, []);

  const statusConfig = {
    normal: { label: 'NORMAL', bg: 'bg-emerald-500', text: 'text-emerald-600', border: 'border-emerald-500', dot: 'bg-emerald-500', icon: <Activity className="w-7 h-7 text-white" /> },
    elevated: { label: 'ELEVATED', bg: 'bg-amber-500', text: 'text-amber-600', border: 'border-amber-500', dot: 'bg-amber-500', icon: <Bell className="w-7 h-7 text-white" /> },
    emergency: { label: 'EMERGENCY', bg: 'bg-red-600', text: 'text-red-600', border: 'border-red-600', dot: 'bg-red-600', icon: <HeartPulse className="w-7 h-7 text-white" /> },
  };

  const status = statusConfig[currentSeverity];

  const fmtTime = (iso: string) => {
    const d = new Date(iso);
    return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
  };

  const getRowSeverity = (r: Reading): Severity => classifyReading(r.heart_rate, r.temperature, settings);

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Link href="/" className="text-slate-400 hover:text-slate-900 transition-colors mr-2">
              <ArrowLeft className="w-5 h-5" />
            </Link>
            <div className="w-9 h-9 rounded-lg bg-red-600 flex items-center justify-center">
              <HeartPulse className="w-5 h-5 text-white" />
            </div>
            <div>
              <span className="font-bold text-slate-900 text-lg">CareBridge</span>
              <span className="ml-2 text-sm text-slate-400">Caregiver Dashboard</span>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <Link href="/patient" className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-100 text-slate-700 text-sm font-medium hover:bg-slate-200 transition-colors">
              <HeartPulse className="w-4 h-4" />
              View Patient
            </Link>
          </div>
          <div className="flex items-center gap-2 text-sm text-slate-500">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            Live
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-6 py-8">
        <div className="grid lg:grid-cols-3 gap-6">
          {/* Left column: Status + Readings */}
          <div className="lg:col-span-2 space-y-6">
            {/* Status card */}
            <div className={`rounded-2xl border-2 ${status.border} bg-white p-6 shadow-sm`}>
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-slate-500 uppercase tracking-wide mb-1">Current Status</p>
                  <div className="flex items-center gap-4">
                    <div className={`w-14 h-14 rounded-2xl ${status.bg} flex items-center justify-center shadow-lg`}>
                      {status.icon}
                    </div>
                    <div>
                      <span className={`text-4xl font-bold ${status.text} tracking-tight`}>{status.label}</span>
                      {latestReading && (
                        <p className="text-sm text-slate-500 mt-1">
                          {latestReading.heart_rate} bpm · {latestReading.temperature}°C
                        </p>
                      )}
                    </div>
                  </div>
                </div>
                <button
                  onClick={callEmergencyContact}
                  disabled={calling}
                  className={`px-6 py-4 rounded-xl font-bold transition-all flex items-center gap-2 ${
                    calling
                      ? 'bg-red-200 text-red-600 cursor-wait'
                      : 'bg-red-600 text-white hover:bg-red-700 shadow-lg shadow-red-600/25 hover:shadow-xl hover:-translate-y-0.5'
                  }`}
                >
                  <Phone className="w-5 h-5" />
                  {calling ? 'Calling...' : 'CALL EMERGENCY CONTACT'}
                </button>
              </div>
              {callStatus && (
                <div className={`mt-4 p-3 rounded-lg text-sm font-medium ${callStatus.startsWith('Failed') ? 'bg-red-50 text-red-700' : 'bg-emerald-50 text-emerald-700'}`}>
                  {callStatus}
                </div>
              )}
            </div>

            {/* Readings table */}
            <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
              <div className="px-6 py-4 border-b border-slate-100 flex items-center gap-2">
                <Activity className="w-5 h-5 text-slate-400" />
                <h2 className="font-semibold text-slate-900">Recent Readings</h2>
                <span className="text-sm text-slate-400 ml-auto">{readings.length} shown</span>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-slate-100 bg-slate-50/50">
                      <th className="text-left px-6 py-3 text-xs font-semibold text-slate-500 uppercase tracking-wide">Time</th>
                      <th className="text-right px-6 py-3 text-xs font-semibold text-slate-500 uppercase tracking-wide">Heart Rate</th>
                      <th className="text-right px-6 py-3 text-xs font-semibold text-slate-500 uppercase tracking-wide">Temperature</th>
                      <th className="text-center px-6 py-3 text-xs font-semibold text-slate-500 uppercase tracking-wide">Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {readings.length === 0 && (
                      <tr>
                        <td colSpan={4} className="px-6 py-12 text-center text-slate-400 text-sm">
                          Waiting for first reading...
                        </td>
                      </tr>
                    )}
                    {readings.map((r) => {
                      const sev = getRowSeverity(r);
                      const dotColor = sev === 'emergency' ? 'bg-red-600' : sev === 'elevated' ? 'bg-amber-500' : 'bg-emerald-500';
                      return (
                        <tr key={r.id} className="border-b border-slate-50 hover:bg-slate-50/50 transition-colors">
                          <td className="px-6 py-3 text-sm text-slate-600 tabular-nums">{fmtTime(r.created_at)}</td>
                          <td className="px-6 py-3 text-sm text-slate-900 font-medium text-right tabular-nums">{r.heart_rate} bpm</td>
                          <td className="px-6 py-3 text-sm text-slate-900 font-medium text-right tabular-nums">{r.temperature}°C</td>
                          <td className="px-6 py-3 text-center">
                            <span className={`inline-block w-3 h-3 rounded-full ${dotColor}`} />
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          </div>

          {/* Right column: Settings + Alerts */}
          <div className="space-y-6">
            {/* Settings */}
            <div className="bg-white rounded-2xl border border-slate-200 shadow-sm">
              <div className="px-6 py-4 border-b border-slate-100 flex items-center gap-2">
                <SettingsIcon className="w-5 h-5 text-slate-400" />
                <h2 className="font-semibold text-slate-900">Threshold Settings</h2>
              </div>
              <div className="p-6 space-y-4">
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-xs font-medium text-slate-500 uppercase tracking-wide">HR Min (bpm)</label>
                    <input
                      type="number"
                      value={settingsForm.heart_rate_min}
                      onChange={(e) => setSettingsForm({ ...settingsForm, heart_rate_min: parseInt(e.target.value) || 0 })}
                      className="mt-1 w-full px-3 py-2 rounded-lg border border-slate-200 text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-slate-900 focus:border-transparent tabular-nums"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-medium text-slate-500 uppercase tracking-wide">HR Max (bpm)</label>
                    <input
                      type="number"
                      value={settingsForm.heart_rate_max}
                      onChange={(e) => setSettingsForm({ ...settingsForm, heart_rate_max: parseInt(e.target.value) || 0 })}
                      className="mt-1 w-full px-3 py-2 rounded-lg border border-slate-200 text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-slate-900 focus:border-transparent tabular-nums"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-medium text-slate-500 uppercase tracking-wide">Temp Min (°C)</label>
                    <input
                      type="number"
                      step="0.1"
                      value={settingsForm.temperature_min}
                      onChange={(e) => setSettingsForm({ ...settingsForm, temperature_min: parseFloat(e.target.value) || 0 })}
                      className="mt-1 w-full px-3 py-2 rounded-lg border border-slate-200 text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-slate-900 focus:border-transparent tabular-nums"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-medium text-slate-500 uppercase tracking-wide">Temp Max (°C)</label>
                    <input
                      type="number"
                      step="0.1"
                      value={settingsForm.temperature_max}
                      onChange={(e) => setSettingsForm({ ...settingsForm, temperature_max: parseFloat(e.target.value) || 0 })}
                      className="mt-1 w-full px-3 py-2 rounded-lg border border-slate-200 text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-slate-900 focus:border-transparent tabular-nums"
                    />
                  </div>
                </div>
                <button
                  onClick={saveSettings}
                  className={`w-full py-2.5 rounded-lg font-medium text-sm flex items-center justify-center gap-2 transition-all ${
                    settingsSaved
                      ? 'bg-emerald-500 text-white'
                      : 'bg-slate-900 text-white hover:bg-slate-800'
                  }`}
                >
                  {settingsSaved ? (
                    <><Check className="w-4 h-4" /> Saved</>
                  ) : (
                    <><Save className="w-4 h-4" /> Save Settings</>
                  )}
                </button>
              </div>
            </div>

            {/* Alerts feed */}
            <div className="bg-white rounded-2xl border border-slate-200 shadow-sm">
              <div className="px-6 py-4 border-b border-slate-100 flex items-center gap-2">
                <Bell className="w-5 h-5 text-slate-400" />
                <h2 className="font-semibold text-slate-900">Alerts Feed</h2>
                {alerts.filter((a) => !a.acknowledged).length > 0 && (
                  <span className="ml-auto px-2 py-0.5 rounded-full bg-red-100 text-red-700 text-xs font-bold">
                    {alerts.filter((a) => !a.acknowledged).length} new
                  </span>
                )}
              </div>
              <div className="max-h-[500px] overflow-y-auto">
                {alerts.length === 0 && (
                  <div className="px-6 py-12 text-center text-slate-400 text-sm">
                    No alerts yet.
                  </div>
                )}
                {alerts.map((a) => (
                  <div
                    key={a.id}
                    className={`px-6 py-4 border-b border-slate-50 ${a.acknowledged ? 'opacity-60' : ''}`}
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          <span className={`w-2 h-2 rounded-full ${a.severity === 'emergency' ? 'bg-red-600' : 'bg-amber-500'}`} />
                          <span className={`text-xs font-bold uppercase tracking-wide ${a.severity === 'emergency' ? 'text-red-600' : 'text-amber-600'}`}>
                            {a.severity}
                          </span>
                          <span className="text-xs text-slate-400 flex items-center gap-1">
                            <Clock className="w-3 h-3" />
                            {fmtTime(a.created_at)}
                          </span>
                        </div>
                        <p className="text-sm text-slate-700 break-words">{a.message}</p>
                      </div>
                      {a.acknowledged ? (
                        <span className="flex-shrink-0 flex items-center gap-1 text-xs text-emerald-600 font-medium">
                          <Check className="w-4 h-4" /> Acknowledged
                        </span>
                      ) : (
                        <button
                          onClick={() => acknowledgeAlert(a.id)}
                          className="flex-shrink-0 px-3 py-1.5 rounded-lg bg-slate-900 text-white text-xs font-medium hover:bg-slate-800 transition-colors"
                        >
                          Acknowledge
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
