import { NextResponse } from 'next/server';
import twilio from 'twilio';

export async function POST() {
  const accountSid = process.env.TWILIO_ACCOUNT_SID;
  const authToken = process.env.TWILIO_AUTH_TOKEN;
  const fromPhone = process.env.TWILIO_PHONE_NUMBER;
  const toPhone = process.env.EMERGENCY_CONTACT_PHONE;

  if (!accountSid || !authToken || !fromPhone || !toPhone) {
    return NextResponse.json(
      { error: 'Twilio is not configured. Set TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN, TWILIO_PHONE_NUMBER, and EMERGENCY_CONTACT_PHONE environment variables.' },
      { status: 500 },
    );
  }

  try {
    const client = twilio(accountSid, authToken);

    const call = await client.calls.create({
      twiml: '<Response><Say>CareBridge emergency alert. This is an automated call from the CareBridge monitoring system. The patient Ramesh has triggered an emergency alert. Please check on the patient immediately.</Say></Response>',
      to: toPhone,
      from: fromPhone,
    });

    return NextResponse.json({
      message: `Emergency call placed successfully. Call ID: ${call.sid}`,
      callSid: call.sid,
    });
  } catch (err) {
    const message = err instanceof Error ? err.message : 'Unknown error';
    return NextResponse.json(
      { error: `Failed to place call: ${message}` },
      { status: 500 },
    );
  }
}
