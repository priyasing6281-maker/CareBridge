'use client';

import Link from 'next/link';
import { HeartPulse, Activity, ShieldCheck, Bell, Phone, ArrowRight } from 'lucide-react';

export default function Home() {
  return (
    <div className="min-h-screen bg-white">
      {/* Hero */}
      <div className="relative overflow-hidden bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
        <div className="absolute inset-0 opacity-10" style={{ backgroundImage: 'radial-gradient(circle at 20% 50%, rgba(239,68,68,0.3) 0%, transparent 50%), radial-gradient(circle at 80% 80%, rgba(16,185,129,0.2) 0%, transparent 50%)' }} />
        <div className="relative max-w-5xl mx-auto px-6 py-20 sm:py-28">
          <div className="flex items-center gap-3 mb-8">
            <div className="w-12 h-12 rounded-xl bg-red-600 flex items-center justify-center shadow-lg shadow-red-600/30">
              <HeartPulse className="w-7 h-7 text-white" />
            </div>
            <span className="text-2xl font-bold text-white tracking-tight">CareBridge</span>
          </div>

          <h1 className="text-4xl sm:text-6xl font-bold text-white tracking-tight leading-tight max-w-2xl">
            Real-time elderly health monitoring with instant caregiver alerts.
          </h1>
          <p className="mt-6 text-lg sm:text-xl text-slate-300 max-w-xl leading-relaxed">
            A hackathon prototype that simulates patient vitals — heart rate and body temperature —
            and notifies caregivers the moment readings cross safe thresholds.
          </p>

          <div className="mt-10 flex flex-col sm:flex-row gap-4">
            <Link
              href="/patient"
              className="group inline-flex items-center justify-center gap-2 px-8 py-4 rounded-xl bg-red-600 text-white font-semibold text-lg hover:bg-red-700 transition-all shadow-lg shadow-red-600/25 hover:shadow-xl hover:shadow-red-600/30 hover:-translate-y-0.5"
            >
              <HeartPulse className="w-5 h-5" />
              Patient View
              <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
            </Link>
            <Link
              href="/dashboard"
              className="group inline-flex items-center justify-center gap-2 px-8 py-4 rounded-xl bg-white/10 backdrop-blur text-white font-semibold text-lg hover:bg-white/20 transition-all border border-white/20 hover:-translate-y-0.5"
            >
              <Activity className="w-5 h-5" />
              Caregiver Dashboard
              <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
            </Link>
          </div>
        </div>
      </div>

      {/* Features */}
      <div className="max-w-5xl mx-auto px-6 py-20">
        <h2 className="text-3xl font-bold text-slate-900 tracking-tight text-center mb-4">
          Two screens. One lifeline.
        </h2>
        <p className="text-slate-500 text-center mb-14 max-w-2xl mx-auto">
          The patient screen shows live vitals in big, readable numbers. The caregiver dashboard
          tracks every reading in real time and flags the moment something looks wrong.
        </p>

        <div className="grid md:grid-cols-3 gap-8">
          <FeatureCard
            icon={<HeartPulse className="w-6 h-6 text-red-600" />}
            title="Live Vital Signs"
            description="Heart rate and body temperature update every two seconds with realistic drift — and an emergency simulation button."
          />
          <FeatureCard
            icon={<Bell className="w-6 h-6 text-amber-500" />}
            title="Instant Alerts"
            description="When readings cross configurable thresholds, an alert is created instantly and the caregiver is notified in real time."
          />
          <FeatureCard
            icon={<Phone className="w-6 h-6 text-red-600" />}
            title="Emergency Calling"
            description="One tap on the caregiver dashboard places a real phone call to the patient's emergency contact via Twilio."
          />
        </div>

        <div className="mt-14 flex items-center justify-center gap-3 text-slate-400">
          <ShieldCheck className="w-5 h-5" />
          <span className="text-sm font-medium">Prototype simulation. Not a medical device. Not a diagnosis.</span>
        </div>
      </div>
    </div>
  );
}

function FeatureCard({
  icon,
  title,
  description,
}: {
  icon: React.ReactNode;
  title: string;
  description: string;
}) {
  return (
    <div className="group p-7 rounded-2xl border border-slate-200 bg-white hover:border-slate-300 hover:shadow-lg transition-all hover:-translate-y-1">
      <div className="w-12 h-12 rounded-xl bg-slate-50 flex items-center justify-center mb-5 group-hover:scale-110 transition-transform">
        {icon}
      </div>
      <h3 className="text-lg font-semibold text-slate-900 mb-2">{title}</h3>
      <p className="text-slate-500 leading-relaxed text-sm">{description}</p>
    </div>
  );
}
