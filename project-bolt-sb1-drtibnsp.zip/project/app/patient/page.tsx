'use client';

import { useEffect, useRef, useState, useCallback } from 'react';
import Link from 'next/link';
import { HeartPulse, Thermometer, AlertTriangle, CheckCircle2, Siren, ArrowLeft, Activity } from 'lucide-react';
import { getSupabase, classifyReading, DEFAULT_SETTINGS, type Reading, type Alert, type Settings, type Severity } from '@/lib/supabase/client';

export default function PatientPage() {
  const [heartRate, setHeartRate] = useState(75);
  const [temperature, setTemperature] = useState(36.8);
  const [severity, setSeverity] = useState<Severity>('normal');
  const [emergencyActive, setEmergencyActive] = useState(false);
  const [emergencyCountdown, setEmergencyCountdown] = useState(0);
  const [acknowledgedAt, setAcknowledgedAt] = useState<string | null>(null);
  const [settings, setSettings] = useState<Settings>(DEFAULT_SETTINGS);
  const [lastReadingTime, setLastReadingTime] = useState<string | null>(null);
  const [showOverlay, setShowOverlay] = useState(false);

  const emergencyRef = useRef(false);
  const emergencyEndRef = useRef<number>(0);
  const settingsRef = useRef(settings);
  const hrRef = useRef(heartRate);
  const tempRef = useRef(temperature);

  useEffect(() => {
    settingsRef.current = settings;
  }, [settings]);
  useEffect(() => {
    hrRef.current = heartRate;
  }, [heartRate]);
  useEffect(() => {
    tempRef.current = temperature;
  }, [temperature]);

  // Load settings once
  useEffect(() => {
    const supabase = getSupabase();
    supabase
      .from('settings')
      .select('*')
      .eq('id', 1)
      .maybeSingle()
      .then(({ data }) => {
        if (data) setSettings(data as Settings);
      });

    const channel = supabase
      .channel('patient-settings')
      .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'settings' }, (payload) => {
        setSettings(payload.new as Settings);
      })
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  // Subscribe to alerts (acknowledgements)
  useEffect(() => {
    const supabase = getSupabase();
    const channel = supabase
      .channel('patient-alerts')
      .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'alerts' }, (payload) => {
        const updated = payload.new as Alert;
        if (updated.acknowledged) {
          setAcknowledgedAt(new Date(updated.created_at).toLocaleTimeString());
          setTimeout(() => setAcknowledgedAt(null), 15000);
        }
      })
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'alerts' }, (payload) => {
        // Reset acknowledged banner when a new alert fires
        const inserted = payload.new as Alert;
        if (!inserted.acknowledged) {
          setAcknowledgedAt(null);
        }
      })
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  // Vitals simulation + insert loop
  useEffect(() => {
    const interval = setInterval(async () => {
      const now = Date.now();
      const inEmergency = emergencyRef.current && now < emergencyEndRef.current;
      const remaining = inEmergency ? Math.ceil((emergencyEndRef.current - now) / 1000) : 0;

      if (emergencyRef.current && now >= emergencyEndRef.current) {
        emergencyRef.current = false;
        setEmergencyActive(false);
        setEmergencyCountdown(0);
      } else if (inEmergency) {
        setEmergencyCountdown(remaining);
      }

      let newHr: number;
      let newTemp: number;

      if (inEmergency) {
        newHr = Math.round(130 + Math.random() * 30);
        newTemp = parseFloat((38.5 + Math.random() * 1.5).toFixed(1));
      } else {
        // Gentle drift around normal
        const prevHr = hrRef.current;
        const prevTemp = tempRef.current;
        newHr = Math.round(Math.max(65, Math.min(85, prevHr + (Math.random() - 0.5) * 6)));
        newTemp = parseFloat(Math.max(36.5, Math.min(37.2, prevTemp + (Math.random() - 0.5) * 0.2)).toFixed(1));
      }

      setHeartRate(newHr);
      setTemperature(newTemp);
      setLastReadingTime(new Date().toLocaleTimeString());

      const sev = classifyReading(newHr, newTemp, settingsRef.current);
      setSeverity(sev);

      // Insert reading
      const supabase = getSupabase();
      const { data: insertedReading } = await supabase
        .from('readings')
        .insert({ heart_rate: newHr, temperature: newTemp })
        .select()
        .single();

      // If crossing thresholds, insert an alert
      if (sev !== 'normal' && insertedReading) {
        const msg =
          sev === 'emergency'
            ? `EMERGENCY: Heart rate ${newHr} bpm, Temperature ${newTemp}°C`
            : `Elevated: Heart rate ${newHr} bpm, Temperature ${newTemp}°C`;

        await supabase.from('alerts').insert({
          message: msg,
          severity: sev,
          acknowledged: false,
        });
      }
    }, 2000);

    return () => clearInterval(interval);
  }, []);

  const triggerEmergency = useCallback(() => {
    emergencyRef.current = true;
    emergencyEndRef.current = Date.now() + 30000;
    setEmergencyActive(true);
    setEmergencyCountdown(30);
  }, []);

  const manualEmergency = useCallback(async () => {
    // 1. Insert an alert immediately
    const supabase = getSupabase();
    await supabase.from('alerts').insert({
      message: 'Manual emergency triggered by patient',
      severity: 'emergency',
      acknowledged: false,
    });

    // 2. Spike vitals for 30 seconds
    triggerEmergency();

    // 3. Show full-screen overlay for 3 seconds
    setShowOverlay(true);
    setTimeout(() => setShowOverlay(false), 3000);
  }, [triggerEmergency]);

  const hrColor =
    severity === 'emergency' ? 'text-red-600' : severity === 'elevated' ? 'text-amber-500' : 'text-slate-900';
  const tempColor = hrColor;

  const cardBorder =
    severity === 'emergency'
      ? 'border-red-500 shadow-red-500/20'
      : severity === 'elevated'
        ? 'border-amber-400 shadow-amber-400/20'
        : 'border-slate-200';

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      {/* Header */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-10">
        <div className="max-w-2xl mx-auto px-5 py-4 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Link href="/" className="flex items-center gap-2 text-slate-400 hover:text-slate-900 transition-colors">
              <ArrowLeft className="w-5 h-5" />
              <span className="text-sm font-medium">Home</span>
            </Link>
            <Link href="/dashboard" className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-100 text-slate-700 text-sm font-medium hover:bg-slate-200 transition-colors">
              <Activity className="w-4 h-4" />
              View Dashboard
            </Link>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-red-600 flex items-center justify-center">
              <HeartPulse className="w-5 h-5 text-white" />
            </div>
            <span className="font-bold text-slate-900">CareBridge</span>
          </div>
        </div>
      </header>

      <main className="flex-1 max-w-2xl w-full mx-auto px-5 py-8">
        {/* Patient identity */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-slate-100 text-slate-700 text-sm font-medium mb-3">
            <Activity className="w-4 h-4 text-slate-500" />
            Live Monitoring
          </div>
          <h1 className="text-3xl font-bold text-slate-900">Ramesh</h1>
          <p className="text-slate-500 mt-1">72 years old · Patient</p>
          {lastReadingTime && (
            <p className="text-xs text-slate-400 mt-2">Last reading: {lastReadingTime}</p>
          )}
        </div>

        {/* Alert banners */}
        {severity !== 'normal' && !acknowledgedAt && (
          <div className="mb-6 rounded-xl bg-red-600 text-white p-4 flex items-center gap-3 shadow-lg shadow-red-600/20 animate-in fade-in slide-in-from-top-2 duration-300">
            <AlertTriangle className="w-6 h-6 flex-shrink-0" />
            <div>
              <p className="font-bold">ALERT — Caregiver notified</p>
              <p className="text-sm text-red-100">
                {severity === 'emergency' ? 'Emergency-level readings detected.' : 'Readings outside safe range.'}
              </p>
            </div>
          </div>
        )}

        {acknowledgedAt && (
          <div className="mb-6 rounded-xl bg-emerald-500 text-white p-4 flex items-center gap-3 shadow-lg shadow-emerald-500/20 animate-in fade-in slide-in-from-top-2 duration-300">
            <CheckCircle2 className="w-6 h-6 flex-shrink-0" />
            <div>
              <p className="font-bold">Caregiver acknowledged</p>
              <p className="text-sm text-emerald-50">Response confirmed at {acknowledgedAt}</p>
            </div>
          </div>
        )}

        {/* Vitals cards */}
        <div className="grid gap-5 mb-8">
          {/* Heart Rate */}
          <div className={`bg-white rounded-2xl border-2 ${cardBorder} p-6 sm:p-8 shadow-sm transition-all duration-300`}>
            <div className="flex items-center gap-3 mb-4">
              <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${severity === 'emergency' ? 'bg-red-100' : 'bg-slate-100'}`}>
                <HeartPulse className={`w-6 h-6 ${severity === 'emergency' ? 'text-red-600' : 'text-slate-700'}`} />
              </div>
              <div>
                <p className="text-sm font-medium text-slate-500 uppercase tracking-wide">Heart Rate</p>
                <p className="text-xs text-slate-400">beats per minute</p>
              </div>
            </div>
            <div className="flex items-baseline gap-2">
              <span className={`text-7xl font-bold tabular-nums ${hrColor} tracking-tight`}>
                {heartRate}
              </span>
              <span className="text-2xl font-medium text-slate-400">bpm</span>
            </div>
          </div>

          {/* Temperature */}
          <div className={`bg-white rounded-2xl border-2 ${cardBorder} p-6 sm:p-8 shadow-sm transition-all duration-300`}>
            <div className="flex items-center gap-3 mb-4">
              <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${severity === 'emergency' ? 'bg-red-100' : 'bg-slate-100'}`}>
                <Thermometer className={`w-6 h-6 ${severity === 'emergency' ? 'text-red-600' : 'text-slate-700'}`} />
              </div>
              <div>
                <p className="text-sm font-medium text-slate-500 uppercase tracking-wide">Body Temperature</p>
                <p className="text-xs text-slate-400">degrees Celsius</p>
              </div>
            </div>
            <div className="flex items-baseline gap-2">
              <span className={`text-7xl font-bold tabular-nums ${tempColor} tracking-tight`}>
                {temperature.toFixed(1)}
              </span>
              <span className="text-2xl font-medium text-slate-400">°C</span>
            </div>
          </div>
        </div>

        {/* Emergency button */}
        <button
          onClick={triggerEmergency}
          disabled={emergencyActive}
          className={`w-full py-5 rounded-2xl font-bold text-lg transition-all flex items-center justify-center gap-3 ${
            emergencyActive
              ? 'bg-red-200 text-red-700 cursor-not-allowed'
              : 'bg-red-600 text-white hover:bg-red-700 shadow-lg shadow-red-600/25 hover:shadow-xl hover:shadow-red-600/30 hover:-translate-y-0.5 active:translate-y-0'
          }`}
        >
          <Siren className="w-6 h-6" />
          {emergencyActive ? (
            <>
              EMERGENCY ACTIVE — {emergencyCountdown}s remaining
            </>
          ) : (
            'Demo: Trigger Emergency'
          )}
        </button>

        {emergencyActive && (
          <p className="text-center text-sm text-red-600 mt-3 font-medium">
            Vitals will spike for 30 seconds, then return to normal.
          </p>
        )}

        {/* Current thresholds */}
        <div className="mt-8 p-4 rounded-xl bg-slate-100 border border-slate-200">
          <p className="text-xs font-semibold text-slate-500 uppercase tracking-wide mb-2">Safe Range (set by caregiver)</p>
          <div className="flex flex-wrap gap-x-6 gap-y-1 text-sm text-slate-700">
            <span>Heart rate: {settings.heart_rate_min}–{settings.heart_rate_max} bpm</span>
            <span>Temperature: {settings.temperature_min}–{settings.temperature_max}°C</span>
          </div>
        </div>
      </main>

      {/* Footer disclaimer */}
      <footer className="bg-white border-t border-slate-200 py-4">
        <p className="text-center text-xs text-slate-400 px-4">
          Prototype simulation. Not a medical device. Not a diagnosis.
        </p>
      </footer>

      {/* Floating emergency button — always visible */}
      <button
        onClick={manualEmergency}
        disabled={emergencyActive}
        className={`fixed bottom-6 right-6 z-50 px-8 py-5 rounded-2xl font-bold text-xl shadow-2xl transition-all flex items-center gap-3 ${
          emergencyActive
            ? 'bg-red-300 text-red-700 cursor-not-allowed'
            : 'bg-red-600 text-white hover:bg-red-700 shadow-red-600/40 hover:scale-105 animate-pulse'
        }`}
        aria-label="Emergency"
      >
        <Siren className="w-7 h-7" />
        EMERGENCY
      </button>

      {/* Full-screen emergency overlay */}
      {showOverlay && (
        <div className="fixed inset-0 z-[100] bg-red-600 flex items-center justify-center animate-in fade-in duration-300">
          <div className="text-center px-6">
            <Siren className="w-20 h-20 text-white mx-auto mb-6 animate-pulse" />
            <h2 className="text-4xl sm:text-5xl font-bold text-white tracking-tight">
              EMERGENCY ALERT SENT
            </h2>
            <p className="mt-4 text-xl text-red-100 font-medium">
              Caregiver notified
            </p>
          </div>
        </div>
      )}
    </div>
  );
}
