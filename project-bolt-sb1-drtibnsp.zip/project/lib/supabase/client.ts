'use client';

import { createClient, SupabaseClient } from '@supabase/supabase-js';

let client: SupabaseClient | null = null;

export function getSupabase(): SupabaseClient {
  if (client) return client;

  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const anonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;

  if (!url || !anonKey) {
    throw new Error('Missing NEXT_PUBLIC_SUPABASE_URL or NEXT_PUBLIC_SUPABASE_ANON_KEY');
  }

  client = createClient(url, anonKey, {
    realtime: { params: { eventsPerSecond: 10 } },
  });

  return client;
}

export type Reading = {
  id: string;
  heart_rate: number;
  temperature: number;
  created_at: string;
};

export type Alert = {
  id: string;
  message: string;
  severity: 'elevated' | 'emergency';
  acknowledged: boolean;
  created_at: string;
};

export type Settings = {
  id: number;
  heart_rate_min: number;
  heart_rate_max: number;
  temperature_min: number;
  temperature_max: number;
};

export const DEFAULT_SETTINGS: Settings = {
  id: 1,
  heart_rate_min: 60,
  heart_rate_max: 100,
  temperature_min: 36.0,
  temperature_max: 37.5,
};

export type Severity = 'normal' | 'elevated' | 'emergency';

export function classifyReading(
  heartRate: number,
  temperature: number,
  settings: Settings,
): Severity {
  const hrEmergency = heartRate > settings.heart_rate_max + 20;
  const tempEmergency = temperature > settings.temperature_max + 0.8;

  if (hrEmergency || tempEmergency) return 'emergency';

  const hrElevated =
    heartRate < settings.heart_rate_min || heartRate > settings.heart_rate_max;
  const tempElevated =
    temperature < settings.temperature_min || temperature > settings.temperature_max;

  if (hrElevated || tempElevated) return 'elevated';

  return 'normal';
}
