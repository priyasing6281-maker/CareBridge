/*
# CareBridge — Elderly Health Monitoring Prototype (Hackathon)

1. New Tables
- `readings`
  - `id` (uuid, PK)
  - `heart_rate` (int, simulated BPM)
  - `temperature` (numeric, simulated °C)
  - `created_at` (timestamptz, defaults now())
- `alerts`
  - `id` (uuid, PK)
  - `message` (text, human-readable alert text)
  - `severity` (text, 'elevated' | 'emergency')
  - `acknowledged` (boolean, default false)
  - `created_at` (timestamptz, defaults now())
- `settings`
  - `id` (int, PK, single row = 1)
  - `heart_rate_min` (int, default 60)
  - `heart_rate_max` (int, default 100)
  - `temperature_min` (numeric, default 36.0)
  - `temperature_max` (numeric, default 37.5)

2. Realtime
- Enables Postgres Logical Replication (required by Supabase Realtime).
- Adds all three tables to the `supabase_realtime` publication so the frontend
  receives INSERT / UPDATE events via the Supabase JS client.

3. Security
- This is a single-tenant prototype with NO authentication and a single demo user.
- RLS is enabled on all tables.
- All four CRUD policies use `TO anon, authenticated` with `USING (true)` / `WITH CHECK (true)`
  because the data is intentionally shared/public for this demo. This is documented
  and intentional — not a shortcut around an ownership check.
*/

-- ─── readings ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS readings (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  heart_rate  int NOT NULL,
  temperature numeric(5,2) NOT NULL,
  created_at  timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE readings ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_readings" ON readings;
CREATE POLICY "anon_select_readings" ON readings FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_readings" ON readings;
CREATE POLICY "anon_insert_readings" ON readings FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_readings" ON readings;
CREATE POLICY "anon_update_readings" ON readings FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_readings" ON readings;
CREATE POLICY "anon_delete_readings" ON readings FOR DELETE
  TO anon, authenticated USING (true);

CREATE INDEX IF NOT EXISTS readings_created_at_idx ON readings (created_at DESC);

-- ─── alerts ───────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS alerts (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  message      text NOT NULL,
  severity     text NOT NULL DEFAULT 'elevated',
  acknowledged boolean NOT NULL DEFAULT false,
  created_at   timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE alerts ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_alerts" ON alerts;
CREATE POLICY "anon_select_alerts" ON alerts FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_alerts" ON alerts;
CREATE POLICY "anon_insert_alerts" ON alerts FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_alerts" ON alerts;
CREATE POLICY "anon_update_alerts" ON alerts FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_alerts" ON alerts;
CREATE POLICY "anon_delete_alerts" ON alerts FOR DELETE
  TO anon, authenticated USING (true);

CREATE INDEX IF NOT EXISTS alerts_created_at_idx ON alerts (created_at DESC);

-- ─── settings ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS settings (
  id               int PRIMARY KEY DEFAULT 1,
  heart_rate_min   int NOT NULL DEFAULT 60,
  heart_rate_max   int NOT NULL DEFAULT 100,
  temperature_min  numeric(5,2) NOT NULL DEFAULT 36.0,
  temperature_max  numeric(5,2) NOT NULL DEFAULT 37.5,
  CONSTRAINT settings_single_row CHECK (id = 1)
);

ALTER TABLE settings ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_settings" ON settings;
CREATE POLICY "anon_select_settings" ON settings FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_settings" ON settings;
CREATE POLICY "anon_insert_settings" ON settings FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_settings" ON settings;
CREATE POLICY "anon_update_settings" ON settings FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_settings" ON settings;
CREATE POLICY "anon_delete_settings" ON settings FOR DELETE
  TO anon, authenticated USING (true);

-- Seed the single settings row so the dashboard has defaults immediately.
INSERT INTO settings (id, heart_rate_min, heart_rate_max, temperature_min, temperature_max)
VALUES (1, 60, 100, 36.0, 37.5)
ON CONFLICT (id) DO NOTHING;

-- ─── Realtime publication ─────────────────────────────────
-- Ensure logical replication is enabled (required by Supabase Realtime).
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_publication WHERE pubname = 'supabase_realtime'
  ) THEN
    BEGIN
      CREATE PUBLICATION supabase_realtime;
    EXCEPTION WHEN OTHERS THEN
      -- ignore if it was created concurrently
      NULL;
    END;
  END IF;
END $$;

-- Add tables to the realtime publication so the JS client receives events.
-- DROP then re-add is safe and idempotent.
DO $$
BEGIN
  BEGIN
    ALTER PUBLICATION supabase_realtime DROP TABLE readings;
  EXCEPTION WHEN OTHERS THEN NULL;
  END;
  BEGIN
    ALTER PUBLICATION supabase_realtime DROP TABLE alerts;
  EXCEPTION WHEN OTHERS THEN NULL;
  END;
  BEGIN
    ALTER PUBLICATION supabase_realtime DROP TABLE settings;
  EXCEPTION WHEN OTHERS THEN NULL;
  END;
  BEGIN
    ALTER PUBLICATION supabase_realtime ADD TABLE readings;
  EXCEPTION WHEN OTHERS THEN NULL;
  END;
  BEGIN
    ALTER PUBLICATION supabase_realtime ADD TABLE alerts;
  EXCEPTION WHEN OTHERS THEN NULL;
  END;
  BEGIN
    ALTER PUBLICATION supabase_realtime ADD TABLE settings;
  EXCEPTION WHEN OTHERS THEN NULL;
  END;
END $$;
